<?php
$conn = mysqli_connect('localhost','root','','watchstore') or die('connection failed');
?>